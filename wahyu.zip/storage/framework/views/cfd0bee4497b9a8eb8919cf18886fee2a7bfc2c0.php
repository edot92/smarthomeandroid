<!DOCTYPE html>
<html>
    <head>
        <title>Laravel</title>

        <link href="https://fonts.googleapis.com/css?family=Lato:100" rel="stylesheet" type="text/css">
<script src="<?php echo e(URL::asset('bootstrap/dist/js/bootstrap.js')); ?>"></script>
<script src="<?php echo e(URL::asset('bootstrap/dist/js/bootstrap.js')); ?>"></script>
<link href="<?php echo e(URL::asset('bootstrap/dist/css/bootstrap.css')); ?>" rel="stylesheet" type="text/css">

        <style>
            html, body {
                height: 100%;
            }

            body {
                margin: 0;
                padding: 0;
                width: 100%;
                display: table;
                font-weight: 100;
                font-family: 'Lato';
            }

            .container {
                text-align: center;
                display: table-cell;
                vertical-align: middle;
            }

            .content {
                text-align: center;
                display: inline-block;
            }

            .title {
                font-size: 96px;
            }
        </style>
    </head>
    <body>
        
<div class="container">
   <div class="panel panel-success">
      <div class="panel-heading"><h2>SMARTHOME ANDROID BERBASIS ARDUINO MEGA 2560 </h2></div>
      <div class="panel-body">
<div  class ="row">
	<div class ="col-md-6">
	
    <div class="panel panel-primary">
      <div class="panel-heading"> <h4>Pengaturan Lampu </h4></div>
		<div class="panel-body">
	 
			<div class ="col-md-12">
				<a href="#" class="btn btn-info" role="button">ON LAMPU 1</a>
				<a href="#" class="btn btn-danger" role="button">OFF LAMPU 1</a>
			</div>
			<br> </br>
			<div class ="col-md-12">
				<a href="#" class="btn btn-info" role="button">ON LAMPU 2</a>
				<a href="#" class="btn btn-danger" role="button">OFF LAMPU 2</a>
			</div>
				<br> </br>
			<div class ="col-md-12">
				<a href="#" class="btn btn-info" role="button">ON LAMPU 1</a>
				<a href="#" class="btn btn-danger" role="button">OFF LAMPU 1</a>
			</div>
				<br> </br>
			<div class ="col-md-12">
				<a href="#" class="btn btn-info" role="button">ON LAMPU 1</a>
				<a href="#" class="btn btn-danger" role="button">OFF LAMPU 1</a>
			</div>
				<br> </br>
			<div class ="col-md-12">
				<a href="#" class="btn btn-info" role="button">ON LAMPU 1</a>
				<a href="#" class="btn btn-danger" role="button">OFF LAMPU 1</a>
			</div>
		</div>
    </div>
 </div>
	<div class ="col-md-6">
	<div class="panel panel-primary">
      <div class="panel-heading"> <h4>Pengaturan Fan </h4></div>
		<div class="panel-body">
	 
			<div class ="col-md-12">
				<a href="#" class="btn btn-info" role="button">ON LAMPU 1</a>
				<a href="#" class="btn btn-danger" role="button">OFF LAMPU 1</a>
			</div>
			<br> </br>
			
		</div>
    </div>
		<div class="panel panel-primary">
      <div class="panel-heading"> <h4>Pengaturan Pintu Gerbang </h4></div>
		<div class="panel-body">
	 
			<div class ="col-md-12">
				<a href="#" class="btn btn-info" role="button">ON LAMPU 1</a>
				<a href="#" class="btn btn-danger" role="button">OFF LAMPU 1</a>
			</div>
			<br> </br>
			
		</div>
    </div>
	
	</div>
	
 </div> 
 <div  class ="row">
 <div class ="col-md-12">
 	<div class="panel panel-primary">
      <div class="panel-heading"> <h4>NILAI SUHU RUANGAN</h4></div>
		<div class="panel-body">
	 <div class ="col-md-4">
	 </div>
					<div class ="col-md-4">
							<form class="form-horizontal" role="form">
  <div class="form-group">
    <label class="control-label col-sm-4" for="suhu"></label>
    <div class="col-sm-4">
      <input type="text" class="form-control" id="suhu" placeholder="Derajat Celcius">
    </div>
  </div>

</form>

					</div>
						 <div class ="col-md-4">
	 </div>
					<br> </br>
			</div>		
		</div>
    </div>
 </div> 
</div>
    </div>	
    </body>
</html>
